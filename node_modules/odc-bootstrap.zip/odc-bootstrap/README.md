# ODC-Bootstrap
A bootstrap theme for ODC that implements the ODC style guide.

## Usage
To build the theme, run `npm run build`, which will compile the sass into a Bootstrap theme into the `dist` directory. 

To view the docs, run `npm run docs`, which will use the compiled theme and display documentation demonstrating the theme.

If you are importing odc-bootstrap into a SASS file, you need to set the `$odc-bootstrap-src-path` variable to the location of the odc-bootstrap `src` directory within node_modules before importing **altaBootstrapTheme.scss**. To import, copy these lines into your SASS file:

`$odc-bootstrap-src-path: "~odc-bootstrap/src/alta/";`

`@import "~odc-bootstrap/src/alta/altaBootstrapTheme.scss";`

#### Gradle
Alternatively, you can use Gradle to build the project as well.  Use this if you don't have `npm` installed on your
machine.

```./gradlew build``` is equivalent to `npm run build`

```./gradlew npmDocs``` is equivalent to `npm run docs`

#### To use the theme (WIP)
1. Run `npm install --save odc-bootstrap@git+ssh://git@gitlab.oracledatacloud.com:odc-commons/odc-bootstrap.git`

2. Include the following in your index.html:
`<link rel="stylesheet" type="text/css" href="node_modules/odc-bootstrap/dist/altaBootstrapTheme.min.css">`


## Contributing
If you are contributing to this project, you must ensure the sass files always compile successfully. To facilitate, you can run `npm test`. Any additional themes or base sass files not included in the altaBootstrapTheme need to be included in the **gulpfile.js**. 

The Alta theme entrypoint is **altaBootstrapTheme.scss**, but variables are organized in separate files, as well as DOM-specific styles. 

Documentation is expected for all additions. To aide contributing, you can run `gulp watch` and `npm run docs` to simultaneously compile the sass and reload the docs. 

#### Publishing
We publish our npm package through **CI**. To spur that publish, an engineer must do the following on master:

```bash
npm version [major|minor|patch]
git push && git push --tags
```