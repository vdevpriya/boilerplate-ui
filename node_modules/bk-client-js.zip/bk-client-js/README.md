[![pipeline status](https://gitlab.oracledatacloud.com/odc-commons/bk-client-js/badges/master/pipeline.svg)](https://gitlab.oracledatacloud.com/odc-commons/bk-client-js/commits/master)

# bk-client-js

NodeJS client to various BlueKai/DMP REST services.

Note: Currently, this only runs on a Node environment, not on a browser.

## Install dependencies

```
npm install
```

## Build the package

```
npm run build 
```

## Run in development mode 

```
npm run watch
```

## How to test ( unit/integration )

Run the following commands
```
npm build
npm test             // runs all tests
npm test:unit        // run only unit tests
npm test:integration // run only integration tests
```

To test an individual file, run:
```
npm test -- filename
```

example:
```
npm test -- test/client/js/components/common/dropDown.spec.js
```

To recursively test within a directory, run:
```
npm test -- directoryPath
```

example:
```
npm test -- test/client
```

To run tests that match a certain description, run:
```
npm test -- -g "Search Text" (Case Sensitive)
```

example:
```
npm test -- -g "CategoryClient" 
```

Arguments can be combined, such as:
```
npm test -- test/client -g "Category"
```

## Tagging
We will switch from pull from a feature branch and use tagging per release.
Once we have decided that the library is stable (Gitlab, Jenkins, etc.) then we will tag master. 
You can tag via command line on master branch:
```
git tag -a {version-number} -m {version-message}
git push origin --tags
```

example:
```
git tag -a 1.0.0 -m "My version 1.0.0"
git push origin --tags
```

You can also create tags from:
```
https://gitlab.oracledatacloud.com/odc-commons/bk-client-js/tags/new 
```
Use master branch as a target branch for tagging.

Place this in your package.json:
```
 "bk-client-js": "git+ssh://git@gitlab.oracledatacloud.com:odc-commons/bk-client-js.git#{tag-number}",
``` 
Tag number will be determined per release.

## Publishing
To publish, create a pipeline on **master** in CI and use the variable `VERSION` to upgrade the version (major|minor|patch). 
