/**
 * Builds the expected margin properties for a chart based on the presence of labels.
 * 
 * @returns Object
 */
export const buildMargin = ({xAxisLabel, yAxisLabel}) => {
    let margin = {};
    if (xAxisLabel) {
        margin.bottom = 35;
    }
    if (yAxisLabel) {
        margin.left = 25;
    }
    return margin;
}