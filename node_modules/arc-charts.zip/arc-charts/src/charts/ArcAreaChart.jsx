import React from 'react'
import PropTypes from 'prop-types'

import AreaChart from 'recharts/es6/chart/AreaChart'
import Area from 'recharts/es6/cartesian/Area'
import Brush from 'recharts/es6/cartesian/Brush'
import XAxis from 'recharts/es6/cartesian/XAxis'
import YAxis from 'recharts/es6/cartesian/YAxis'
import Tooltip from 'recharts/es6/component/Tooltip'
import Legend from 'recharts/es6/component/Legend'
import ResponsiveContainer from 'recharts/es6/component/ResponsiveContainer'

import { colorSchemes } from '../config'

const propTypes = {
    /** width of graph container */
    width: PropTypes.number,
    /** height of graph container */
    height: PropTypes.number,
    /** add tooltip to graph */
    tooltip: PropTypes.bool,
    /** add brush to graph */
    brush: PropTypes.bool,
    /** key for x axis */
    xAxisKey: PropTypes.string,
    /** key for y axis */
    yAxisKey: PropTypes.string,
    /** pass in extra y props */
    yProps: PropTypes.object,
    /** pass in extra x props */
    xProps: PropTypes.object,
    /** pass in extra legend props */
    legendProps: PropTypes.object,
    /** pass in extra tooltip props */
    tooltipProps: PropTypes.object,
    /** pass in extra brush props */
    brushProps: PropTypes.object
}

const defaultProps = {
    colorScheme: 'alta'
};

class ArcAreaChart extends React.Component {

    constructor(props) {
        super(props)
    }

    transformChildren() {
        const colorScheme = colorSchemes[this.props.colorScheme]
        let childNodes = this.props.children

        if(Array.isArray(childNodes)) {
            return this.props.children.map((self, i) => {
                let color = colorScheme.colors[i % colorScheme.colors.length],
                    stack = this.props.stack ? { stackId: 1} : ''
                if (self.props.isBaseline) {
                    color = colorScheme.baseline
                }
                return <Area name={self.props.name} type='monotone' key={i} dataKey={self.props.dataKey} fill={color} stroke={color} {...stack} />
            })
        } else {
            let color = colorScheme.colors[0]
            return <Area name={childNodes.props.name} type='monotone' key={0} dataKey={childNodes.props.dataKey} fill={color} stroke={color}/>
        }
    }

    render() {
        let chart = [
                <XAxis {...this.props.xProps}
                    dataKey={this.props.xAxisKey}
                    key='xaxis'
                />, 
                <YAxis {...this.props.yProps} 
                    dataKey={this.props.yAxisKey} 
                    key='yaxis' 
                />, 
                <Legend {...this.props.legendProps} 
                    key='leg'  
                />
        ];
        
        if (this.props.tooltip) {
            chart.push(<Tooltip key='tt' {...this.props.tooltipProps} />)
        }

        if (this.props.brush) {
            chart.push(<Brush key='b' {...this.props.brushProps} />)
        }

        const newChildren = this.transformChildren();
        chart.push(...newChildren);

        return (
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart {...this.props} style={{background:'white'}}>
                    {chart}
                </AreaChart>
            </ResponsiveContainer>
        );
    }
}

ArcAreaChart.propTypes = propTypes;
ArcAreaChart.defaultProps = defaultProps;

export default ArcAreaChart