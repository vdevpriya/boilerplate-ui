import React from 'react'
import PropTypes from 'prop-types'
import { colorSchemes } from '../config'
import LineChart from 'recharts/es6/chart/LineChart'
import Line from 'recharts/es6/cartesian/Line'
import XAxis from 'recharts/es6/cartesian/XAxis'
import YAxis from 'recharts/es6/cartesian/YAxis'
import Tooltip from 'recharts/es6/component/Tooltip'
import Legend from 'recharts/es6/component/Legend'
import ResponsiveContainer from 'recharts/es6/component/ResponsiveContainer'

const propTypes = {
    /** width of graph container */
    width: PropTypes.number,
    /** height of graph container */
    height: PropTypes.number,
    /** add tooltip to graph */
    tooltip: PropTypes.bool,
    /** key for x axis */
    xAxisKey: PropTypes.string,
    /** key for y axis */
    yAxisKey: PropTypes.string,
    /** pass in extra y props */
    yProps: PropTypes.object,
    /** pass in extra x props */
    xProps: PropTypes.object,
    /** pass in extra legend props */
    legendProps: PropTypes.object,
    /** pass in extra tooltip props */
    tooltipProps: PropTypes.object
}

const defaultProps = {
    colorScheme: 'alta'
};

class ArcLineChart extends React.Component {

    constructor(props) {
        super(props)
    }

    detectColor(index, isBaseline) {
        const colorScheme = colorSchemes[this.props.colorScheme]
        let color = colorScheme.colors[index % colorScheme.colors.length]
        if (isBaseline) {
            color = colorScheme.baseline
        }
        return color; 
    }

    transformChildren() {
        let childNodes = this.props.children
        if(Array.isArray(childNodes)) {
            return this.props.children.map((self, i) => {
                let color = this.detectColor(i, self.props.isBaseline) 
                return <Line name={self.props.name} type='monotone' key={i} dataKey={self.props.dataKey} activeDot={{r: 8}} stroke={color} />
            })
        } else {
            let color = this.detectColor(0, this.props.isBaseline) 
            return <Line name={childNodes.props.name} type='monotone' key={0} dataKey={childNodes.props.dataKey} activeDot={{r: 8}} stroke={color} />
        }
    }

    render() {
        let chart = [
            <XAxis {...this.props.xProps} 
                dataKey={this.props.xAxisKey} 
                key='xaxis'
            />, 
            <YAxis {...this.props.yProps}
                dataKey={this.props.yAxisKey}  
                key='yaxis'
            />, 
            <Legend {...this.props.legendProps} 
                key='leg'  
            />
        ];

        if (this.props.tooltip) {
            chart.push(<Tooltip key='tt'  {...this.props.tooltipProps} />)
        }

        const newChildren = this.transformChildren();
        chart.push(...newChildren);

        return (
            <ResponsiveContainer width="100%" height="100%">
                <LineChart {...this.props} style={{background:'white'}}>
                    {chart}
                </LineChart>
            </ResponsiveContainer>
        )
    }
}

ArcLineChart.propTypes = propTypes;
ArcLineChart.defaultProps = defaultProps;

export default ArcLineChart;