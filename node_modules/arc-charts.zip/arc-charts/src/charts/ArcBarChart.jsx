import React, {Component} from 'react';
import PropTypes from 'prop-types';
import { animationSpeedMS, colorSchemes } from '../config';
import ResponsiveContainer from 'recharts/es6/component/ResponsiveContainer';
import BarChart from 'recharts/es6/chart/BarChart';
import Bar from 'recharts/es6/cartesian/Bar';
import Brush from 'recharts/es6/cartesian/Brush';
import XAxis from 'recharts/es6/cartesian/XAxis';
import YAxis from 'recharts/es6/cartesian/YAxis';
import Label from 'recharts/es6/component/Label';
import LabelList from 'recharts/es6/component/LabelList';
import Tooltip from 'recharts/es6/component/Tooltip';
import Legend from 'recharts/es6/component/Legend';
import CustomTooltip from '../components/CustomTooltip';
import {CustomLabel} from '../components/CustomLabel';

import {CustomHorizontalBar} from '../components/CustomHorizontalBar';
import {CustomVerticalBar} from '../components/CustomVerticalBar';
import {XAxisTickWithTopPadding} from '../components/XAxisTickWithTopPadding';

import {buildMargin} from '../utils';

const propTypes = {
    /** 
     * Function to provide an override for what the tooltip displays. 
     * The first param given is the data point, the second is the label.
     */
    customTooltipRenderer: PropTypes.func,
    /** 
     * direction the values on the axis travel. Traditional bar chart is horizontal,
     * while vertical is chosen to display values on the y-axis and bars running along the x-axis.
     */
    layout: PropTypes.oneOf(['horizontal', 'vertical']),
    /** whether to show the legend or not */
    showLegend: PropTypes.bool,
    hideXAxis: PropTypes.bool,
    hideYAxis: PropTypes.bool,
    /** add tooltip to graph */
    tooltip: PropTypes.bool,
    /** add brush to graph */
    brush: PropTypes.bool,
    /** key for x axis */
    xAxisKey: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the x axis. 
     * Given the tick value and should return a String.
     */
    xAxisTickFormatter: PropTypes.func,
    /** label for x axis */
    xAxisLabel: PropTypes.string,
    /** key for y axis */
    yAxisKey: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the y axis. 
     * Given the tick value and should return a String.
     */
    yAxisTickFormatter: PropTypes.func,
    /** Optional override for the width of the y-axis in pixels */
    yAxisWidth: PropTypes.number,
    /** label for y axis */
    yAxisLabel: PropTypes.string,
    yAxisOnClick: PropTypes.func,
    /** pass in extra brush props */
    brushProps: PropTypes.object
};

const defaultProps = {
    colorScheme: 'alta',
    layout: 'horizontal',
    hideXAxis: false,
    hideYAxis: false,
    yAxisWidth: 60
};

class ArcBarChart extends Component {
    transformChildren() {
        const {layout} = this.props;
        const colorScheme = colorSchemes[this.props.colorScheme];
        return this.props.children.map((series, i) => {
            const {label, name, dataKey, ...rest} = series.props;

            let color = colorScheme.colors[i % colorScheme.colors.length];
            if (series.props.isBaseline) {
                color = colorScheme.baseline;
            }

            /*
                Build labels on the ends of the bars, handling horizontal or vertical bars 
            */
            let labelList;
            if (label) {
                const position = layout === 'vertical' ? 'right' : 'top';
                if (label instanceof Function) {
                    // show labels resulting from the provided function 
                    labelList = <LabelList valueAccessor={label} content={CustomLabel} position={position} />;
                } else {
                    // show labels using just the key
                    labelList = <LabelList dataKey={dataKey} content={CustomLabel} position={position} />;
                }
            }

            return (
                <Bar 
                    animationDuration={animationSpeedMS}
                    name={name} 
                    key={i} 
                    dataKey={dataKey} 
                    fill={color} 
                    shape={layout === 'vertical' ? <CustomVerticalBar /> : <CustomHorizontalBar />}
                    {...rest}
                >
                {labelList}
                </Bar>
            );
        });
    }

    render() {
        const {
            customTooltipRenderer, 
            layout, 
            showLegend, 
            hideXAxis,
            hideYAxis,
            tooltip,
            xAxisKey, 
            xAxisLabel,
            xAxisPadding,
            xAxisTickFormatter,
            yAxisKey, 
            yAxisLabel,
            yAxisOnClick,
            yAxisPadding, 
            yAxisTickFormatter,
            yAxisWidth,
            ...rest} = this.props;

        // children are rendered in order
        let chart = [
                <XAxis 
                    dataKey={xAxisKey} 
                    key='xaxis'
                    padding={xAxisPadding ? xAxisPadding : layout==='horizontal' ? {right:0} : {right:25}} 
                    hide={hideXAxis}
                    type={layout==='horizontal' ? 'category' : 'number'}
                    tick={<XAxisTickWithTopPadding />}
                    tickFormatter={xAxisTickFormatter}
                >
                    <Label value={xAxisLabel} position='bottom' />
                </XAxis>, 
                <YAxis 
                    dataKey={yAxisKey} 
                    key='yaxis'
                    padding={yAxisPadding ? yAxisPadding : layout==='vertical' ? {top:0} : {top:15}} 
                    width={yAxisWidth}
                    hide={hideYAxis}
                    onClick={(e) => yAxisOnClick ? yAxisOnClick(e.value) : null}
                    type={layout==='vertical' ? 'category' : 'number'}
                    tickFormatter={yAxisTickFormatter}
                > {
                    /* TODO This does not work great for long axis labels. 
                    The textAnchor and verticalAnchor on the Label does not
                    affect the outcome because of the `position`. Attempting
                    to use inline styles affects the display, but the position
                    needs to be affected with something like
                    position={{x:yAxisLabel.length - 100, y:0}}
                    */}
                    <Label 
                        value={yAxisLabel} 
                        angle={-90}
                        position='left'
                    />
                </YAxis> 
            ];

        if (showLegend) {
            chart.push(<Legend align='right' key='leg' verticalAlign='top' />);
        }

        if (tooltip) {
            let customTooltip;
            if (customTooltipRenderer) {
                customTooltip = <CustomTooltip format={customTooltipRenderer} />;
            }
            chart.push(<Tooltip key='tt' content={customTooltip}/>)
        }

        if (this.props.brush) {
            chart.push(<Brush key='b' {...this.props.brushProps} />)
        }

        const newChildren = this.transformChildren();
        chart.push(...newChildren);

        // build the margins for the chart based on configuration
        const margin = buildMargin(this.props);

        return (
            <ResponsiveContainer width='100%' height='100%'>
                <BarChart layout={layout} margin={margin} {...rest} style={{background:'white'}}>
                    {chart}
                </BarChart>
            </ResponsiveContainer>
        );
    }
}

ArcBarChart.propTypes = propTypes;
ArcBarChart.defaultProps = defaultProps;

export default ArcBarChart;