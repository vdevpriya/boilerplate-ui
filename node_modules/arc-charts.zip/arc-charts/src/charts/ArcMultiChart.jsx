import React, {Component} from 'react';
import PropTypes from 'prop-types';
import { animationSpeedMS, colorSchemes } from '../config';
import ResponsiveContainer from 'recharts/es6/component/ResponsiveContainer';
import ComposedChart from 'recharts/es6/chart/ComposedChart';
import Bar from 'recharts/es6/cartesian/Bar';
import Line from 'recharts/es6/cartesian/Line'
import XAxis from 'recharts/es6/cartesian/XAxis';
import YAxis from 'recharts/es6/cartesian/YAxis';
import Label from 'recharts/es6/component/Label';
import LabelList from 'recharts/es6/component/LabelList';
import Tooltip from 'recharts/es6/component/Tooltip';
import Legend from 'recharts/es6/component/Legend';
import CustomTooltip from '../components/CustomTooltip';
import {CustomLabel} from '../components/CustomLabel';

import {CustomHorizontalBar} from '../components/CustomHorizontalBar';
import {CustomVerticalBar} from '../components/CustomVerticalBar';
import {XAxisTickWithTopPadding} from '../components/XAxisTickWithTopPadding';

import {buildMargin} from '../utils';

const propTypes = {
    /** 
     * Function to provide an override for what the tooltip displays. 
     * The first param given is the data point, the second is the label.
     */
    customTooltipRenderer: PropTypes.func,
    /** 
     * Direction the values on the axis travel. Traditional bar chart is horizontal,
     * while vertical is chosen to display values on the y-axis and bars running along the x-axis.
     */
    layout: PropTypes.oneOf(['horizontal', 'vertical']),
    /** whether to show the legend or not */
    showLegend: PropTypes.bool,
    hideXAxis: PropTypes.bool,
    hideYAxis: PropTypes.bool,
    /** add tooltip to graph */
    tooltip: PropTypes.bool,
    /** key for x axis */
    xAxisKey: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the x axis. 
     * Given the tick value and should return a String.
     */
    xAxisTickFormatter: PropTypes.func,
    /** label for x axis */
    xAxisLabel: PropTypes.string,
    /** key for y axis */
    yAxisKey: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the y axis. 
     * Given the tick value and should return a String.
     */
    yAxisTickFormatter: PropTypes.func,
    /** Optional override for the width of the y-axis in pixels */
    yAxisWidth: PropTypes.number,
    /** label for y axis */
    yAxisLabel: PropTypes.string
};

const defaultProps = {
    colorScheme: 'alta',
    layout: 'horizontal',
    hideXAxis: false,
    hideYAxis: false,
    yAxisWidth: 60
};

class ArcMultiChart extends Component {
    constructor(props) {
        super(props);
    }

    buildLabelList(label, dataKey, layout) {
        /*
            Build labels on the ends of the bars, handling horizontal or vertical bars 
        */
        let labelList;
        if (label) {
            const position = layout === 'vertical' ? 'right' : 'top';
            if (label instanceof Function) {
                // show labels resulting from the provided function 
                labelList = <LabelList valueAccessor={label} content={CustomLabel} position={position} />;
            } else {
                // show labels using just the key
                labelList = <LabelList dataKey={dataKey} content={CustomLabel} position={position} />;
            }
        }
        return labelList;
    }

    buildBar(series, i, color, layout) {
        const {label, name, dataKey, ...rest} = series.props;

        return (
            <Bar 
                animationDuration={animationSpeedMS}
                name={name} 
                key={i} 
                dataKey={dataKey} 
                fill={color} 
                shape={layout === 'vertical' ? <CustomVerticalBar /> : <CustomHorizontalBar />}
                {...rest}
            >
                {this.buildLabelList(label, dataKey, layout)}
            </Bar>
        );
    }

    buildLine(series, i, color, layout) {
        const {label, dataKey, name, ...rest} = series.props;
        return (
            <Line 
                name={name} 
                type='monotone' 
                key={i} 
                dataKey={dataKey} 
                activeDot={{r: 8}} 
                stroke={color} >
                {this.buildLabelList(label, dataKey, layout)}
            </Line>
        );
    }

    transformChildren() {
        const {layout} = this.props;
        const colorScheme = colorSchemes[this.props.colorScheme];
        return this.props.children.map((series, i) => {
            let color = colorScheme.colors[i % colorScheme.colors.length];
            if (series.props.isBaseline) {
                color = colorScheme.baseline;
            }
            return series.props.type === 'bar' ? 
                    this.buildBar(series, i, color, layout) : 
                    this.buildLine(series, i, color, layout);
        });
    }

    render() {
        const {
            customTooltipRenderer, 
            layout, 
            showLegend, 
            hideXAxis,
            hideYAxis,
            tooltip,
            xAxisKey, 
            xAxisLabel,
            xAxisPadding,
            xAxisTickFormatter,
            yAxisKey, 
            yAxisLabel,
            yAxisPadding, 
            yAxisTickFormatter,
            yAxisWidth,
            ...rest} = this.props;

        // children are rendered in order
        let chart = [ 
                <XAxis 
                    dataKey={xAxisKey} 
                    key='xaxis'
                    padding={xAxisPadding ? xAxisPadding : layout==='horizontal' ? {right:0} : {right:25}} 
                    hide={hideXAxis}
                    type={layout==='horizontal' ? 'category' : 'number'}
                    tick={<XAxisTickWithTopPadding />}
                    tickFormatter={xAxisTickFormatter}
                >
                    <Label value={xAxisLabel} position='bottom' />
                </XAxis>, 
                <YAxis 
                    dataKey={yAxisKey} 
                    key='yaxis'
                    padding={layout==='vertical' ? {top:0} : {top:15}} 
                    width={yAxisWidth}
                    hide={hideYAxis}
                    type={layout==='vertical' ? 'category' : 'number'}
                    tickFormatter={yAxisTickFormatter}
                >
                    <Label value={yAxisLabel} angle={-90} position='left' />
                </YAxis>
            ];
        
        if (showLegend) {
            chart.push(<Legend align="right" key='leg' verticalAlign="top" />);
        }

        if (tooltip) {
            let customTooltip;
            if (customTooltipRenderer) {
                customTooltip = <CustomTooltip format={customTooltipRenderer} />;
            }
            chart.push(<Tooltip key='tt' content={customTooltip}/>)
        }

        const newChildren = this.transformChildren();
        chart.push(...newChildren);

        // build the margins for the chart based on configuration
        const margin = buildMargin(this.props);

        return (
            <ResponsiveContainer width="100%" height="100%">
                <ComposedChart layout={layout} margin={margin} {...rest} style={{background:'white'}}>
                    {chart}
                </ComposedChart>
            </ResponsiveContainer>
        );
    }
}

ArcMultiChart.propTypes = propTypes;
ArcMultiChart.defaultProps = defaultProps;

export default ArcMultiChart;