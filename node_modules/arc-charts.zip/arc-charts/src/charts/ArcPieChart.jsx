import React from 'react'
import PropTypes from 'prop-types'
import { colorSchemes } from '../config'
import PieChart from 'recharts/es6/chart/PieChart'
import Pie from 'recharts/es6/polar/Pie'
import Cell from 'recharts/es6/component/Cell'
import Tooltip from 'recharts/es6/component/Tooltip'
import Legend from 'recharts/es6/component/Legend'
import Sector from 'recharts/es6/shape/Sector'
import ResponsiveContainer from 'recharts/es6/component/ResponsiveContainer'
import simpleNumber from 'at-cerebral/src/fn/numberFormat/simpleNumber'
import classnames from 'classnames'

const propTypes = {
    /** width of graph container */
    width: PropTypes.number,
    /** height of graph container */
    height: PropTypes.number,
    /** key for each sector's value */
    dataKey: PropTypes.string,
    /** % or pixel number of X coordinate for center of pie chart */
    cX: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string
    ]),
    /** % or pixel number of Y coordinate for center of pie chart */
    cY: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string
    ]),
    /** Stroke color between Cells */
    stroke: PropTypes.string,
    legendOnClick: PropTypes.func
}

const defaultProps = {
    colorScheme: 'alta'
};

const defaultLegend = {
    align: 'left',
    verticalAlign: 'top',
    layout: 'vertical',
}

const PIE_EXPANSION = 40; 

class ArcPieChart extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            activeIndex: 0
        }

        this.onPieEnter = this.onPieEnter.bind(this); 
    }

    onPieEnter(data, index) {
        this.setState({
          activeIndex: index,
        });
      }

    transformChildren() {
        const colorScheme = colorSchemes[this.props.colorScheme];
        const stroke = this.props.stroke; 
        let childNodes = this.props.children,
            pies;
        if(Array.isArray(childNodes)) {
            pies = childNodes.map((self, k) => {
                let pie = <Pie 
                            {...self.props} 
                            stroke={stroke} 
                            dataKey={this.props.dataKey} 
                            key={k}>
                            {self.props.data.map((cell, i) => {
                                // use the colorIndex specified on the cell, or else use i
                                let cellColorIndex = cell.colorIndex !== undefined ? cell.colorIndex : i;
                                let color = cell.color || colorScheme.colors[cellColorIndex % colorScheme.colors.length];
                                return <Cell key={i} fill={color} />
                            })}
                        </Pie>
                return pie
            })
        } else {
            pies = <Pie 
                    {...childNodes.props} 
                    stroke={stroke} 
                    activeIndex={this.state.activeIndex} 
                    activeShape={renderActiveShape} 
                    onMouseEnter={this.onPieEnter}
                    dataKey={this.props.dataKey} 
                    key={0}>
                    {childNodes.props.data.map((cell, i) => {
                        // use the colorIndex specified on the cell, or else use i
                        let cellColorIndex = cell.colorIndex !== undefined ? cell.colorIndex : i;
                        let color = cell.color || colorScheme.colors[cellColorIndex % colorScheme.colors.length];
                        return <Cell key={i} fill={color} />
                    })}
                </Pie>
        }

        return pies
        
    }

    render() {
        let chart = [<Legend key='leg' content={(props) => renderLegend({...this.props, ...props})} {...defaultLegend} activeIndex={this.state.activeIndex} />];

        if (this.props.tooltip) {
            chart.push(<Tooltip key='tt' />)
        }

        const newChildren = this.transformChildren();
        Array.isArray(newChildren) ? chart.push(...newChildren) : chart.push(newChildren);
        
        return (
            <ResponsiveContainer width="100%" height="100%">
                <PieChart height={this.props.height} width={this.props.width} style={{background:'white'}}>
                    {chart}
                </PieChart>
            </ResponsiveContainer>
        )
    }
}

const renderActiveShape = (props) => {
    return(
        <Sector
            {...props}
            outerRadius={props.outerRadius + PIE_EXPANSION}
        />
    );
}

const renderLegendBubble = (entry, index, activeIndex) => {
    const legendBubbleClass = classnames('legend-bubble', { 
        'expand-bubble': index == activeIndex 
    }); 

    return(
        <div className={legendBubbleClass} style={{background: entry.color}}></div>
    );
}

const renderLegend = (props) => {
  const { payload, activeIndex, legendOnClick } = props;

  return (
    <ul style={{listStyleType: 'none'}}>
      {
        payload.map((entry, index) => (
          <li className='legend-list' key={`item-${index}`} onClick={() => legendOnClick ? legendOnClick(entry.value) : null}>
            {renderLegendBubble(entry, index, activeIndex)} 
            {/* Legend decimals retrieved if the payload contains a property of legendDecimals, else it'll be 0 */}
            <span>{entry.value} - {simpleNumber(entry.payload.value, entry.payload.legendDecimals)}</span> 
          </li> 
        ))
      }
    </ul>
  );
}

ArcPieChart.propTypes = propTypes;
ArcPieChart.defaultProps = defaultProps;

export default ArcPieChart;