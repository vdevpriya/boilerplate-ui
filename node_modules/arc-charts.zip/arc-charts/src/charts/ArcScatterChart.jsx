import React, {Component} from 'react';
import PropTypes from 'prop-types';

import {ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, ZAxis, Label, Tooltip, Legend} from 'recharts';

import CustomTooltip from '../components/CustomTooltip';
import {XAxisTickWithTopPadding} from '../components/XAxisTickWithTopPadding';

import { colorSchemes } from '../config';
import {buildMargin} from '../utils';

const propTypes = {
    /** 
     * Function to provide an override for what the tooltip displays. 
     * The first param given is the data point, the second is the label.
     */
    customTooltipRenderer: PropTypes.func,
    /** whether to show the legend or not */
    showLegend: PropTypes.bool,
    /** add tooltip to graph */
    tooltip: PropTypes.bool,
    /** key for x axis */
    xAxisKey: PropTypes.string,
    /** label for x axis */
    xAxisLabel: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the x axis. 
     * Given the tick value and should return a String.
     */
    xAxisTickFormatter: PropTypes.func,
    /** key for y axis */
    yAxisKey: PropTypes.string,
    /** label for y axis */
    yAxisLabel: PropTypes.string,
    /** 
     * Optional function for formatting the tick marks on the y axis. 
     * Given the tick value and should return a String.
     */
    yAxisTickFormatter: PropTypes.func,
    /** key for z axis */
    zAxisKey: PropTypes.string,
    /** z axis requires a range, this specifies the max value in the range */
    zAxisMax: PropTypes.number,
    /** z axis requires a range, this specifies the min value in the range */
    zAxisMin: PropTypes.number
};

const defaultProps = {
    showLegend: true,
    zAxisMax: 1000,
    zAxisMin: 1,
    colorScheme: 'alta'
};

class ArcScatterChart extends Component {

	constructor(props) {
		super(props);
    }
    
    /**
     * Create Scatters from the series given in the props, and provide each a unique color
     */
	transformChildren() {
        const colorScheme = colorSchemes[this.props.colorScheme];
        
        // go through all Series given, either as one Series or multiple (array)
        if (Array.isArray(this.props.children)) {
            return this.props.children.map((series, i) => {
                const {name, data, isBaseline} = series.props;
                let color = colorScheme.colors[i % colorScheme.colors.length];
                if (isBaseline) {
                    color = colorScheme.baseline;
                }
                return (
                    <Scatter 
                        data={data} 
                        fill={color}
                        key={i} 
                        name={name}  />
                );
            });
        } else {
            // just use the first color
            return [
                <Scatter 
                    data={this.props.children.props.data} 
                    fill={colorScheme.colors[0]} 
                    key='0' 
                    name={this.props.children.props.name} 
                />
            ];
        }
    }

    render() {
        const {
            customTooltipRenderer, 
            showLegend, 
            tooltip,
            xAxisKey, 
            xAxisLabel,
            xAxisTickFormatter,
            yAxisKey, 
            yAxisLabel,
            yAxisTickFormatter,
            zAxisKey,
            zAxisMax,
            zAxisMin,
            ...rest} = this.props;

        let chart = [
                <XAxis 
                    dataKey={xAxisKey} 
                    key='xaxis'
                    padding={{right:10}} 
                    type='number'
                    tick={<XAxisTickWithTopPadding />}
                    tickFormatter={xAxisTickFormatter}
                >
                    <Label value={xAxisLabel} position='bottom' />
                </XAxis>, 
                <YAxis 
                    dataKey={yAxisKey} 
                    key='yaxis'
                    type='number'
                    padding={{top:10}} 
                    tickFormatter={yAxisTickFormatter}
                >
                    <Label value={yAxisLabel} angle={-90} position='left' />
                </YAxis>
            ];
            
        if (zAxisKey) {
            chart.push(
                <ZAxis 
                    dataKey={zAxisKey} 
                    key='zaxis'
                    range={[zAxisMin, zAxisMax]} />
            );
        }
            
        if (showLegend) {
            chart.push(<Legend align='right' key='leg' verticalAlign='top' />);
        }

        if (tooltip) {
            let customTooltip;
            if (customTooltipRenderer) {
                customTooltip = <CustomTooltip format={customTooltipRenderer} />;
            }
            chart.push(<Tooltip key='tt' content={customTooltip}/>);
        }

        const newChildren = this.transformChildren();
        chart.push(...newChildren);

        // build the margins for the chart based on configuration
        const margin = buildMargin(this.props);

        return (
            <ResponsiveContainer width="100%" height="100%">
                <ScatterChart {...this.props} margin={margin} {...rest} style={{background:'white'}}>
                    {chart}
                </ScatterChart>
            </ResponsiveContainer>
        );
    }
}

ArcScatterChart.propTypes = propTypes;
ArcScatterChart.defaultProps = defaultProps;

export default ArcScatterChart;