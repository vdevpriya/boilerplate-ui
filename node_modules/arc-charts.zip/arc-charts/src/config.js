const animationSpeedMS = 1000;

const palette = {
    alta: {
        orange: '#F5AC76',
        blue: '#80CDDF',
        green: '#ADD38F',
        purple: '#AA83B9',
        baseline: '#E7E8EA',
        dark: '#11120D'
    }, 
    odc: {
        orange: '#f0c67c',
        blue: '#6ab2c0',
        green: '#95c39c',
        purple: '#c08798',
        baseline: '#515253',
        dark: '#11120D'
    },
    vapor: {
        chart1a: '#5F3DC4',
        chart1b: '#5C7CFA',
        chart1c: '#74C0FC',
        chart1d: '#99E9F2',
        chart1e: '#38D9A9',
        baseline: '#495057'
    }
}

const colorSchemes = {
    alta: {
        colors: [
            palette.alta.blue,
            palette.alta.orange,
            palette.alta.green,
            palette.alta.purple
        ],
        baseline: palette.alta.baseline
    },
    odc: {
        colors: [
            palette.odc.orange,
            palette.odc.blue,
            palette.odc.green,
            palette.odc.purple
        ],
        baseline: palette.odc.baseline
    },
    vapor: {
        colors: [
            palette.vapor.chart1a,
            palette.vapor.chart1b,
            palette.vapor.chart1c,
            palette.vapor.chart1d,
            palette.vapor.chart1e
        ],
        baseline: palette.vapor.baseline 
    }
}

export { animationSpeedMS, colorSchemes }