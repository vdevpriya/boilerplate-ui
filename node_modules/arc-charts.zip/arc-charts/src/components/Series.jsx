import React, {PureComponent} from 'react';
import PropTypes from 'prop-types';

class Series extends PureComponent {
	render() {
		return (
			<div {...this.props} />
		)
	}
}

Series.propTypes = {
	type: PropTypes.oneOf(['bar', 'line'])
};

export default Series;