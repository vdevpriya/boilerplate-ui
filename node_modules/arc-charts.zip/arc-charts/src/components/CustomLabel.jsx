import React from 'react';

export const CustomLabel = (props) => {
    const { x, y, width, height, position, value, formatter, offset } = props;

    let moddedX = x, moddedY = y, textAnchor = 'middle';
    if (position === 'right') {
        moddedX = x + width + offset; 
        moddedY = y + height / 2 + 4; // 4 brings it more inline with the height of the bar
        textAnchor = 'left';
    } else {
        moddedX = x + width / 2;
        moddedY = y - offset;
    }


    return (
        <g>
            <text 
                x={moddedX} y={moddedY} height={height} width={width} 
                fill='#666' style={{fontSize:'10px'}} 
                className='recharts-text recharts-label'
                textAnchor={textAnchor}>
                {formatter ? formatter(value) : value}
            </text>
        </g>
    );
};