import React from 'react';
import PropTypes from 'prop-types';

const propTypes = {
    type: PropTypes.string,
    payload: PropTypes.array,
    label: PropTypes.string,
    format: PropTypes.func.isRequired
};

class CustomTooltip extends React.Component {
	constructor(props) {
		super(props)
	}

    render() {
        const { active } = this.props;

        if (active) {
            const { format, payload, label } = this.props;
            if (payload) {
                return format(payload[0].payload, label);
            }
            return null;
        }

        return null;
    }
}

export default CustomTooltip;