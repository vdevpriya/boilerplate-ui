import React from 'react';

/**
 * Tick override to add some padding above the text
 */
export const XAxisTickWithTopPadding = (props) => {
    const {x, y, stroke, payload} = props;
		
   	return (
    	  <g transform={`translate(${x},${y})`}>
            <text x={0} y={0} dy={13} textAnchor="middle" fill="#666">{payload.value}</text>
        </g>
    );
}