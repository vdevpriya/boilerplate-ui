import React from 'react';

/**
 * The bars for the bar chart sit a little into the axis. These custom bars move the shape away from 
 * the x (horizontal) and y (vertical) axis as needed.
 */
export const CustomHorizontalBar = ({ fill, x, y, width, height }) => 
    <path x={x} y={y} fill={fill} d={`M ${x},${y - 0.5} h ${width} v ${height} h ${-1 * width} Z`} />
;