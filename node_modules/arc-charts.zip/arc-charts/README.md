ARC Charts
==========
[![pipeline status](https://gitlab.oracledatacloud.com/odc-commons/arc-charts/badges/master/pipeline.svg)](https://gitlab.oracledatacloud.com/odc-commons/arc-charts/commits/master)

This library offers charting options styled with the Alta design theme. You also have the opportunity to inject your own color theme.

## Contributing

To start contributing, you will need Node 8+.

Next, you will want to first prepare the workspace with `npm i`. 

To build the bundle for distribution, you will run `npm run build`. 

To play with a chart's configuration and implementation, run `npm run sandbox` to start the sandbox environment.

To run tests, run `npm test`

## Publishing
To publish, create a pipeline on **master** in CI and use the variable `VERSION` to upgrade the version (major|minor|patch). 